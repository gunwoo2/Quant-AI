"""
batch_insider.py — 내부자 거래 (Finnhub 위임)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
★ v4: SEC EDGAR 직접 호출 제거 (rate limit + 83분 행 이슈)
      내부자 거래 수집은 batch_layer2_v2.py의 run_insider_collection()이 담당.
      이 파일은 하위호환 용도로만 유지 (import 에러 방지).
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def run_insider_trades():
    """
    내부자 거래 수집 — Finnhub 위임.
    
    실제 수집은 batch_layer2_v2.py → run_insider_collection()에서 수행.
    (Finnhub API, rate limiter 적용, 병렬 GroupB에서 실행)
    
    이 함수는 scheduler 하위호환을 위해 유지.
    """
    print("[INSIDER] ℹ️  Finnhub 위임 (batch_layer2_v2 GroupB에서 이미 실행)")
    print("[INSIDER] ✅ skip (중복 방지)")


if __name__ == "__main__":
    run_insider_trades()