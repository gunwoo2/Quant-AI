"""
scheduler.py — QUANT AI v3.7
============================
v3.6 → v3.7:
  + Step 4.5 차트 패턴 감지 (batch_chart_patterns)
  + Step 4.6 Fear & Greed Index (batch_fear_greed)
  + _s_notify_all 함수 def 누락 버그 fix
  
v3.6:
  ★ 안전장치 [2]: Step 1 가격 수집 실패 시 전체 중단 + 긴급 알림
  ★ 안전장치 [1]: Step 7 전 가격 신선도 검증 → stale 종목 경고
  ★ 부분 실패 허용: 10% 미만 실패 시 계속, 10%+ 실패 시 중단

스케줄:
  평일 21:00 ET  — 일일 배치
  토요일 09:00 ET — 주간 성과 리포트
  매월 1일 09:00 ET — 월간 성과 리포트
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import datetime, date, timedelta
import traceback
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")
logger = logging.getLogger("scheduler")

PRICE_FAIL_THRESHOLD_PCT = int(os.environ.get("PRICE_FAIL_THRESHOLD_PCT", "10"))

def run_all(calc_date: date = None):
    """일일 배치 파이프라인 — 안전장치 포함"""
    if calc_date is None:
        calc_date = datetime.now().date()
    start_all = datetime.now()
    results = {}
    print(f"\n{'='*60}\n  QUANT AI v3.7 일일 배치 — {calc_date}\n{'='*60}")

    # ━━ Step 1: 가격 수집 (★ 안전장치) ━━
    results["1_price"] = _run_step("1/10 가격 수집", lambda: _s_price(calc_date))

    if results["1_price"].startswith("FAIL"):
        print(f"\n🚨 Step 1 가격 수집 실패 — 이후 배치 중단!")
        _emergency_abort(calc_date, results, start_all, results["1_price"])
        return results

    stale_info = _check_price_health(calc_date)
    if stale_info and stale_info.get("abort"):
        print(f"\n🚨 가격 데이터 {stale_info['stale_pct']:.0f}% 미갱신 — 이후 배치 중단!")
        results["1_price_health"] = f"FAIL: stale {stale_info['stale_pct']:.0f}%"
        _emergency_abort(calc_date, results, start_all,
                         f"미갱신 종목 {stale_info['stale_count']}개 ({stale_info['stale_pct']:.0f}%)")
        return results
    elif stale_info and stale_info.get("stale_count", 0) > 0:
        results["1_price_health"] = f"WARN: stale {stale_info['stale_count']}개"
        print(f"  ⚠️ 미갱신 종목 {stale_info['stale_count']}개 (임계 미만 → 계속 진행)")
    else:
        results["1_price_health"] = "OK"

    # ━━ Step 2~6: 점수 계산 ━━
    results["2_fin"]       = _run_step("2/10 파생 재무",       lambda: _s_fin(calc_date))
    results["3_l1"]        = _run_step("3/10 Layer 1",         lambda: _s_l1(calc_date))
    results["4_l3"]        = _run_step("4/10 Layer 3",         lambda: _s_l3(calc_date))
    results["4.5_pattern"] = _run_step("4.5 차트패턴",         lambda: _s_chart_patterns(calc_date))
    results["4.6_fg"]      = _run_step("4.6 Fear&Greed",       lambda: _s_fear_greed(calc_date))
    results["5_l2"]        = _run_step("5/10 Layer 2",         lambda: _s_l2(calc_date))

    if _should_earnings(calc_date):
        results["5.5_ec"]  = _run_step("5.5 어닝콜",           lambda: _s_ec(calc_date))
    else:
        results["5.5_ec"]  = "SKIP"

    results["5.6_insider"] = _run_step("5.6 내부자거래",       lambda: _s_insider())
    results["5.7_macro"]   = _run_step("5.7 거시지표",         lambda: _s_macro())
    results["6_final"]     = _run_step("6/10 최종 합산",       lambda: _s_final(calc_date))

    # ━━ Step 7: 트레이딩 시그널 ━━
    results["7_trading"]   = _run_step("7/10 트레이딩 시그널",  lambda: _s_trading(calc_date))

    # ━━ Step 8: 알림 발송 ━━
    results["8_notify"]    = _run_step("8/8 일일 종합 알림",   lambda: _s_notify_all(calc_date, results, start_all))

    # Step 9/10 → APScheduler 별도 job (이중 실행 방지)

    elapsed = datetime.now() - start_all
    ok   = sum(1 for v in results.values() if v == "OK")
    fail = sum(1 for v in results.values() if isinstance(v, str) and v.startswith("FAIL"))
    skip = sum(1 for v in results.values() if v == "SKIP")
    warn = sum(1 for v in results.values() if isinstance(v, str) and v.startswith("WARN"))
    print(f"\n{'='*60}\n  결과: 성공={ok} 실패={fail} 경고={warn} 스킵={skip} | 소요: {elapsed}\n{'='*60}")
    return results

# ══════════════════════════════════════════════
#  ★ 안전장치 함수
# ══════════════════════════════════════════════

def _check_price_health(calc_date: date) -> dict:
    """가격 신선도 검증 → abort 여부 결정"""
    try:
        from notifier import check_price_freshness
        info = check_price_freshness()
        total = info.get("total", 0)
        stale_count = info.get("stale_count", 0)
        if total == 0:
            return {"abort": True, "stale_count": 0, "stale_pct": 100,
                    "message": "realtime 가격 데이터 0건"}
        stale_pct = (stale_count / total) * 100
        if stale_count > 0:
            stale_tickers = [s["ticker"] for s in info.get("stale", [])[:10]]
            print(f"  [HEALTH] 미갱신 종목: {stale_count}/{total} ({stale_pct:.1f}%)")
            print(f"  [HEALTH] 예시: {', '.join(stale_tickers)}")
        return {
            "abort": stale_pct >= PRICE_FAIL_THRESHOLD_PCT,
            "stale_count": stale_count,
            "stale_pct": stale_pct,
            "stale_tickers": [s["ticker"] for s in info.get("stale", [])],
        }
    except Exception as e:
        print(f"  [HEALTH] 신선도 검증 실패: {e}")
        return None


def _emergency_abort(calc_date: date, results: dict, start_time, error_msg: str):
    """안전장치 발동 → 긴급 알림 + 중단"""
    elapsed = (datetime.now() - start_time).total_seconds()
    try:
        from notifier import notify_price_fetch_failure, notify_batch_complete
        stale_tickers = []
        try:
            from notifier import check_price_freshness
            info = check_price_freshness()
            stale_tickers = [s["ticker"] for s in info.get("stale", [])[:20]]
        except Exception:
            pass
        notify_price_fetch_failure(calc_date, str(error_msg), stale_tickers)
        results["ABORT"] = f"FAIL: {error_msg}"
        notify_batch_complete(calc_date, elapsed, results)
    except Exception as e:
        print(f"  [ABORT] 긴급 알림 발송 실패: {e}")
        try:
            from notifier import send_message
            send_message(f"🚨 배치 긴급 중단 ({calc_date})\n사유: {error_msg}\n⛔ 수동 확인 필요",
                         channel_key="SYSTEM", private=False)
        except Exception:
            print(f"  [ABORT] 모든 알림 실패!")

# ══════════════════════════════════════════════
#  Step 함수
# ══════════════════════════════════════════════

def _run_step(name, func):
    print(f"\n── {name} ──")
    t = datetime.now()
    try:
        func()
        print(f"✅ {name} ({(datetime.now()-t).total_seconds():.1f}초)")
        return "OK"
    except Exception as e:
        print(f"❌ {name} ({(datetime.now()-t).total_seconds():.1f}초): {e}")
        traceback.print_exc()
        return f"FAIL: {e}"


def _s_price(d):
    from batch.batch_ticker_item_daily import run_daily_price; run_daily_price(d)

def _s_fin(d):
    from batch.batch_ticker_item_daily import run_supplement_financials; run_supplement_financials()

def _s_l1(d):
    from batch.batch_ticker_item_daily import run_quant_score; run_quant_score(d)

def _s_l3(d):
    from batch.batch_layer3_v2 import run_all as r; r(d)

def _s_chart_patterns(d):
    from batch.batch_chart_patterns import run_chart_patterns; run_chart_patterns(d)

def _s_fear_greed(d):
    from batch.batch_fear_greed import run_fear_greed; run_fear_greed(d)

def _s_l2(d):
    from batch.batch_layer2_v2 import run_all as r; r()

def _s_ec(d):
    from batch.batch_earnings_call import run_earnings_call_analysis; run_earnings_call_analysis(d)

def _s_insider():
    from batch.batch_insider import run_insider_trades; run_insider_trades()

def _s_macro():
    from batch.batch_macro import run_macro; run_macro()

def _s_final(d):
    from batch.batch_final_score import run_final_score; run_final_score(d)

def _s_trading(d):
    live = os.environ.get("TRADING_LIVE", "0") == "1"
    from batch.batch_trading_signals import run_trading_signals
    run_trading_signals(calc_date=d, dry_run=not live)

# ══════════════════════════════════════════════
#  Step 8: 일일 종합 알림 (7종 순차 발송)
# ══════════════════════════════════════════════

def _s_notify_all(calc_date, results, start_time):
    """Step 8: 배치 완료 후 모든 일일 알림을 순차 발송."""
    elapsed = (datetime.now() - start_time).total_seconds()
    sent = 0
    fail_list = []

    # 8a: 배치 완료 요약
    try:
        from notifier import notify_batch_complete
        notify_batch_complete(calc_date, elapsed, results)
        sent += 1
        print(f"  [8a] ✅ 배치 완료 알림")
    except Exception as e:
        fail_list.append(f"batch_complete: {e}")
        print(f"  [8a] ⚠️ 배치 완료 알림 실패: {e}")

    # 8b: 등급 변동 알림
    try:
        upgrades, downgrades = _detect_grade_changes(calc_date)
        if upgrades or downgrades:
            from notifier import notify_grade_changes
            notify_grade_changes(calc_date, upgrades, downgrades)
            sent += 1
            print(f"  [8b] ✅ 등급 변동 알림 (↑{len(upgrades)} ↓{len(downgrades)})")
        else:
            print(f"  [8b] ─ 등급 변동 없음")
    except Exception as e:
        fail_list.append(f"grade_changes: {e}")
        print(f"  [8b] ⚠️ 등급 변동 알림 실패: {e}")

    # 8c: 어닝 발표 당일 알림
    try:
        earnings_stocks = _detect_earnings_today(calc_date)
        if earnings_stocks:
            from notifier import notify_earnings_alert
            notify_earnings_alert(calc_date, earnings_stocks)
            sent += 1
            print(f"  [8c] ✅ 어닝 알림 ({len(earnings_stocks)}종목)")
        else:
            print(f"  [8c] ─ 오늘 어닝 없음")
    except Exception as e:
        fail_list.append(f"earnings_alert: {e}")
        print(f"  [8c] ⚠️ 어닝 알림 실패: {e}")

    # 8d: 리스크 경고
    try:
        risk_data = _detect_risk_status(calc_date)
        if risk_data and risk_data["should_warn"]:
            from notifier import notify_risk_warning
            notify_risk_warning(
                calc_date=calc_date, dd_mode=risk_data["dd_mode"],
                drawdown_pct=risk_data["drawdown_pct"],
                cb_level=risk_data.get("cb_level", ""),
                losing_streak=risk_data.get("losing_streak", 0),
                concentration_warn=risk_data.get("concentration_warn"),
            )
            sent += 1
            print(f"  [8d] ✅ 리스크 경고 ({risk_data['dd_mode']})")
        else:
            print(f"  [8d] ─ 리스크 정상")
    except Exception as e:
        fail_list.append(f"risk_warning: {e}")
        print(f"  [8d] ⚠️ 리스크 경고 실패: {e}")

    # 8e: 일일 성과
    try:
        perf = _get_daily_performance(calc_date)
        if perf:
            from notifier import notify_daily_performance
            notify_daily_performance(**perf)
            sent += 1
            print(f"  [8e] ✅ 일일 성과 ({perf['daily_return']:+.2f}%)")
        else:
            print(f"  [8e] ─ 성과 데이터 없음")
    except Exception as e:
        fail_list.append(f"daily_performance: {e}")
        print(f"  [8e] ⚠️ 일일 성과 알림 실패: {e}")

    # 8f: 추가 매수 시그널
    try:
        add_signals = _detect_add_positions(calc_date)
        if add_signals:
            from notifier import notify_add_position
            notify_add_position(calc_date, add_signals)
            sent += 1
            print(f"  [8f] ✅ 추가 매수 알림 ({len(add_signals)}종목)")
        else:
            print(f"  [8f] ─ 추가 매수 시그널 없음")
    except Exception as e:
        fail_list.append(f"add_position: {e}")
        print(f"  [8f] ⚠️ 추가 매수 알림 실패: {e}")

    # 8g: 종합 아침 브리핑
    try:
        briefing_data = _build_morning_briefing(calc_date)
        if briefing_data:
            from notifier import notify_morning_briefing
            notify_morning_briefing(**briefing_data)
            sent += 1
            print(f"  [8g] ✅ 아침 브리핑 발송")
        else:
            print(f"  [8g] ─ 브리핑 데이터 부족")
    except Exception as e:
        fail_list.append(f"morning_briefing: {e}")
        print(f"  [8g] ⚠️ 아침 브리핑 실패: {e}")

    print(f"\n  📨 알림 발송: {sent}건 성공 / {len(fail_list)}건 실패")
    if fail_list:
        for ff in fail_list:
            print(f"     ⚠️ {ff}")

# ═══════════════════════════════════════════════════════════
#  알림 데이터 수집 함수
# ═══════════════════════════════════════════════════════════

def _detect_grade_changes(calc_date):
    from db_pool import get_cursor
    GRADE_ORDER = {"S": 7, "A+": 6, "A": 5, "B+": 4, "B": 3, "C": 2, "D": 1}
    with get_cursor() as cur:
        cur.execute("""
            SELECT t.stock_id, s.ticker, s.company_name,
                   t.grade AS today_grade, t.weighted_score AS today_score,
                   y.grade AS prev_grade, y.weighted_score AS prev_score
            FROM final_scores t
            JOIN stocks s ON s.stock_id = t.stock_id
            LEFT JOIN final_scores y ON y.stock_id = t.stock_id
                AND y.calc_date = (SELECT MAX(calc_date) FROM final_scores WHERE stock_id = t.stock_id AND calc_date < %s)
            WHERE t.calc_date = %s AND y.grade IS NOT NULL AND t.grade != y.grade
        """, (calc_date, calc_date))
        rows = cur.fetchall()
    upgrades, downgrades = [], []
    for r in rows:
        diff = GRADE_ORDER.get(r["today_grade"], 0) - GRADE_ORDER.get(r["prev_grade"], 0)
        if abs(diff) < 2: continue
        item = {"ticker": r["ticker"], "company_name": r["company_name"] or r["ticker"],
                "prev_grade": r["prev_grade"], "new_grade": r["today_grade"],
                "prev_score": float(r["prev_score"] or 0), "new_score": float(r["today_score"] or 0),
                "grade_diff": diff}
        (upgrades if diff > 0 else downgrades).append(item)
    upgrades.sort(key=lambda x: -x["grade_diff"])
    downgrades.sort(key=lambda x: x["grade_diff"])
    return upgrades, downgrades


def _detect_earnings_today(calc_date):
    from db_pool import get_cursor
    try:
        with get_cursor() as cur:
            cur.execute("""
                SELECT DISTINCT s.ticker, s.company_name, fs.weighted_score, fs.grade, ec.report_time
                FROM stocks s
                LEFT JOIN final_scores fs ON fs.stock_id = s.stock_id
                    AND fs.calc_date = (SELECT MAX(calc_date) FROM final_scores WHERE stock_id = s.stock_id)
                LEFT JOIN earnings_calendar ec ON ec.stock_id = s.stock_id AND ec.earnings_date = %s
                WHERE ec.earnings_date IS NOT NULL AND s.is_active = TRUE
                ORDER BY fs.weighted_score DESC NULLS LAST LIMIT 20
            """, (calc_date,))
            rows = cur.fetchall()
        if rows:
            return [{"ticker": r["ticker"], "company_name": r["company_name"] or r["ticker"],
                     "score": float(r["weighted_score"] or 0) if r.get("weighted_score") else 0,
                     "grade": r.get("grade", "?"), "report_time": r.get("report_time", "Unknown")} for r in rows]
    except Exception:
        pass
    return []


def _detect_risk_status(calc_date):
    from db_pool import get_cursor
    try:
        with get_cursor() as cur:
            cur.execute("""
                SELECT total_value,
                       (SELECT MAX(total_value) FROM portfolio_daily_snapshot WHERE portfolio_id = 1) as peak_value
                FROM portfolio_daily_snapshot WHERE portfolio_id = 1
                ORDER BY snapshot_date DESC LIMIT 1
            """)
            row = cur.fetchone()
        if not row or not row["total_value"] or not row["peak_value"]:
            return None
        current = float(row["total_value"])
        peak = float(row["peak_value"])
        dd_pct = ((current - peak) / peak * 100) if peak > 0 else 0
        if dd_pct > -3: dd_mode = "NORMAL"
        elif dd_pct > -5: dd_mode = "CAUTION"
        elif dd_pct > -8: dd_mode = "WARNING"
        elif dd_pct > -12: dd_mode = "DANGER"
        else: dd_mode = "CRITICAL"
        losing_streak = 0
        try:
            with get_cursor() as cur:
                cur.execute("SELECT daily_return FROM portfolio_daily_snapshot WHERE portfolio_id = 1 ORDER BY snapshot_date DESC LIMIT 10")
                for r in cur.fetchall():
                    if float(r["daily_return"] or 0) < 0: losing_streak += 1
                    else: break
        except Exception: pass
        should_warn = dd_mode != "NORMAL" or losing_streak >= 3
        return {"should_warn": should_warn, "dd_mode": dd_mode, "drawdown_pct": round(dd_pct, 2),
                "cb_level": "", "losing_streak": losing_streak, "concentration_warn": None}
    except Exception:
        return None


def _get_daily_performance(calc_date):
    from db_pool import get_cursor
    try:
        with get_cursor() as cur:
            cur.execute("SELECT total_value, daily_return FROM portfolio_daily_snapshot WHERE portfolio_id = 1 AND snapshot_date = %s", (calc_date,))
            today = cur.fetchone()
            if not today: return None
            cur.execute("SELECT price_change_pct FROM stock_prices_realtime WHERE stock_id = (SELECT stock_id FROM stocks WHERE ticker = 'SPY' LIMIT 1)")
            spy_row = cur.fetchone()
            spy_return = float(spy_row["price_change_pct"] or 0) if spy_row else 0
            cur.execute("""
                SELECT s.ticker, spr.price_change_pct as daily_pnl
                FROM portfolio_positions pp JOIN stocks s ON s.stock_id = pp.stock_id
                LEFT JOIN stock_prices_realtime spr ON spr.stock_id = s.stock_id
                WHERE pp.portfolio_id = 1 AND pp.quantity > 0
                ORDER BY spr.price_change_pct DESC NULLS LAST
            """)
            positions = cur.fetchall()
        return {
            "calc_date": calc_date, "portfolio_value": float(today["total_value"]),
            "daily_return": float(today["daily_return"] or 0), "spy_return": spy_return,
            "best_ticker": positions[0]["ticker"] if positions else "",
            "best_pnl": float(positions[0]["daily_pnl"] or 0) if positions else 0,
            "worst_ticker": positions[-1]["ticker"] if positions else "",
            "worst_pnl": float(positions[-1]["daily_pnl"] or 0) if positions else 0,
            "num_positions": len(positions), "total_pnl": float(today["daily_return"] or 0),
        }
    except Exception:
        return None


def _detect_add_positions(calc_date):
    from db_pool import get_cursor
    try:
        with get_cursor() as cur:
            cur.execute("""
                SELECT s.ticker, s.company_name, fs.weighted_score, fs.grade,
                       spr.current_price, ti.rsi_14, pp.avg_cost,
                       (spr.current_price - pp.avg_cost) / NULLIF(pp.avg_cost, 0) * 100 as pnl_pct
                FROM portfolio_positions pp
                JOIN stocks s ON s.stock_id = pp.stock_id
                JOIN final_scores fs ON fs.stock_id = s.stock_id AND fs.calc_date = %s
                LEFT JOIN stock_prices_realtime spr ON spr.stock_id = s.stock_id
                LEFT JOIN technical_indicators ti ON ti.stock_id = s.stock_id
                    AND ti.calc_date = (SELECT MAX(calc_date) FROM technical_indicators WHERE stock_id = s.stock_id)
                WHERE pp.portfolio_id = 1 AND pp.quantity > 0 AND fs.weighted_score >= 65
                  AND (spr.current_price - pp.avg_cost) / NULLIF(pp.avg_cost, 0) * 100 BETWEEN -10 AND -3
            """, (calc_date,))
            return [{"ticker": r["ticker"], "company_name": r["company_name"] or r["ticker"],
                     "price": float(r["current_price"] or 0), "avg_cost": float(r["avg_cost"] or 0),
                     "pnl_pct": round(float(r["pnl_pct"] or 0), 2), "score": float(r["weighted_score"] or 0),
                     "grade": r["grade"], "rsi": float(r["rsi_14"] or 0) if r.get("rsi_14") else None,
                     "reason": f"등급 {r['grade']}({float(r['weighted_score'] or 0):.0f}점)"} for r in cur.fetchall()]
    except Exception:
        return []


def _build_morning_briefing(calc_date):
    from db_pool import get_cursor
    try:
        regime = "UNKNOWN"
        regime_detail = {}
        with get_cursor() as cur:
            cur.execute("SELECT regime, spy_price, spy_ma50, spy_ma200, vix_close FROM market_regime WHERE regime_date = %s ORDER BY regime_date DESC LIMIT 1", (calc_date,))
            row = cur.fetchone()
            if row:
                regime = row["regime"]
                regime_detail = {k: float(row.get(k) or 0) for k in ["spy_price", "spy_ma50", "spy_ma200", "vix_close"]}
        top_buys = []
        with get_cursor() as cur:
            cur.execute("SELECT s.ticker, s.company_name, ts.score, ts.target_price, ts.entry_price FROM trading_signals ts JOIN stocks s ON s.stock_id = ts.stock_id WHERE ts.calc_date = %s AND ts.signal_type = 'BUY' ORDER BY ts.score DESC NULLS LAST LIMIT 5", (calc_date,))
            top_buys = [{"ticker": r["ticker"], "company_name": r["company_name"] or r["ticker"],
                         "score": float(r["score"] or 0), "entry_price": float(r["entry_price"] or 0),
                         "target_price": float(r["target_price"] or 0)} for r in cur.fetchall()]
        watchlist = []
        with get_cursor() as cur:
            cur.execute("SELECT s.ticker, s.company_name, fs.weighted_score, fs.grade, spr.current_price, spr.price_change_pct FROM final_scores fs JOIN stocks s ON s.stock_id = fs.stock_id LEFT JOIN stock_prices_realtime spr ON spr.stock_id = s.stock_id WHERE fs.calc_date = %s AND fs.grade IN ('S','A+') ORDER BY fs.weighted_score DESC LIMIT 10", (calc_date,))
            watchlist = [{"ticker": r["ticker"], "company_name": r["company_name"] or r["ticker"],
                          "score": float(r["weighted_score"] or 0), "grade": r["grade"],
                          "price": float(r["current_price"] or 0) if r.get("current_price") else 0,
                          "change_pct": float(r["price_change_pct"] or 0) if r.get("price_change_pct") else 0} for r in cur.fetchall()]
        earnings_today = _detect_earnings_today(calc_date)
        upgrades, downgrades = _detect_grade_changes(calc_date)
        grade_changes = [{"ticker": u["ticker"], "prev": u["prev_grade"], "new": u["new_grade"], "dir": "UP"} for u in upgrades[:3]]
        grade_changes += [{"ticker": d["ticker"], "prev": d["prev_grade"], "new": d["new_grade"], "dir": "DOWN"} for d in downgrades[:3]]
        portfolio_summary = {}
        try:
            perf = _get_daily_performance(calc_date)
            if perf: portfolio_summary = {"total_value": perf["portfolio_value"], "daily_return": perf["daily_return"], "num_positions": perf["num_positions"]}
        except Exception: pass
        signal_summary = {}
        with get_cursor() as cur:
            cur.execute("SELECT signal_type, COUNT(*) as cnt FROM trading_signals WHERE calc_date = %s GROUP BY signal_type", (calc_date,))
            signal_summary = {r["signal_type"]: r["cnt"] for r in cur.fetchall()}
        return {"calc_date": calc_date, "regime": regime, "regime_detail": regime_detail,
                "top_buys": top_buys or None, "watchlist": watchlist or None,
                "earnings_today": earnings_today or None, "grade_changes": grade_changes or None,
                "portfolio_summary": portfolio_summary or None, "signal_summary": signal_summary or None}
    except Exception as e:
        print(f"  [BRIEFING] 데이터 수집 실패: {e}")
        return None

# ═══════════════════════════════════════════════════════════
#  주간/월간 리포트 + 유틸리티
# ═══════════════════════════════════════════════════════════

def _should_earnings(d):
    if os.environ.get("FORCE_EARNINGS") == "1":
        return True
    return d.month in (1, 4, 7, 10) and 10 <= d.day <= 20


def run_weekly_report(calc_date: date = None):
    if calc_date is None:
        calc_date = datetime.now().date()
    print(f"\n── 주간 리포트 — {calc_date} ──")
    from db_pool import get_cursor
    week_start = calc_date - timedelta(days=7)
    try:
        with get_cursor() as cur:
            cur.execute("SELECT snapshot_date, total_value, daily_return FROM portfolio_daily_snapshot WHERE portfolio_id = 1 AND snapshot_date >= %s ORDER BY snapshot_date", (week_start,))
            snapshots = [dict(r) for r in cur.fetchall()]
        if len(snapshots) < 2:
            print("  주간 데이터 부족 — 스킵"); return
        start_val = float(snapshots[0]["total_value"])
        end_val = float(snapshots[-1]["total_value"])
        week_return = (end_val - start_val) / start_val * 100 if start_val > 0 else 0
        with get_cursor() as cur:
            cur.execute("SELECT close_price FROM stock_prices_daily WHERE stock_id = (SELECT stock_id FROM stocks WHERE ticker = 'SPY' LIMIT 1) AND trade_date >= %s ORDER BY trade_date", (week_start,))
            spy_rows = cur.fetchall()
        spy_weekly = 0
        if len(spy_rows) >= 2:
            spy_weekly = (float(spy_rows[-1]["close_price"]) - float(spy_rows[0]["close_price"])) / float(spy_rows[0]["close_price"]) * 100
        try:
            from notifier import notify_weekly_report
            notify_weekly_report(calc_date=calc_date, portfolio_value=end_val, weekly_return=week_return,
                                 spy_weekly_return=spy_weekly, total_trades=0, win_rate=0,
                                 best_ticker="", best_pnl=0, worst_ticker="", worst_pnl=0)
            print(f"  ✅ 주간 리포트 발송 ({week_return:+.2f}% vs SPY {spy_weekly:+.2f}%)")
        except Exception as e:
            print(f"  ⚠️ 주간 리포트 실패: {e}")
        try:
            with get_cursor() as cur:
                cur.execute("""
                    SELECT s.ticker, fs.grade, fs.weighted_score, pp.market_value
                    FROM portfolio_positions pp JOIN stocks s ON s.stock_id = pp.stock_id
                    LEFT JOIN final_scores fs ON fs.stock_id = s.stock_id
                        AND fs.calc_date = (SELECT MAX(calc_date) FROM final_scores WHERE stock_id = s.stock_id)
                    WHERE pp.portfolio_id = 1 AND pp.quantity > 0
                    ORDER BY fs.weighted_score DESC NULLS LAST
                """)
                positions = cur.fetchall()
            buys = [{"ticker": p["ticker"], "grade": p.get("grade","?"), "score": float(p.get("weighted_score") or 0)} for p in positions if p.get("grade") in ("S","A+")]
            sells = [{"ticker": p["ticker"], "grade": p.get("grade","?"), "score": float(p.get("weighted_score") or 0)} for p in positions if p.get("grade") in ("C","D")]
            adjusts = [{"ticker": p["ticker"], "grade": p.get("grade","?")} for p in positions if p.get("grade") not in ("S","A+","C","D")]
            if buys or sells:
                from notifier import notify_weekly_rebalance
                turnover = (len(buys) + len(sells)) / max(len(positions), 1) * 100
                notify_weekly_rebalance(calc_date, buys, sells, adjusts, turnover)
                print(f"  ✅ 리밸런싱 제안 (증액: {len(buys)} 감액: {len(sells)})")
        except Exception as e:
            print(f"  ⚠️ 리밸런싱 알림 실패: {e}")
    except Exception as e:
        print(f"  ⚠️ 주간 리포트 전체 실패: {e}")


def run_monthly_report(calc_date: date = None):
    if calc_date is None:
        calc_date = datetime.now().date()
    print(f"\n── 월간 리포트 — {calc_date} ──")
    from db_pool import get_cursor
    month_start = (calc_date.replace(day=1) - timedelta(days=1)).replace(day=1)
    try:
        with get_cursor() as cur:
            cur.execute("""
                SELECT MIN(total_value) as min_val, MAX(total_value) as max_val,
                       (array_agg(total_value ORDER BY snapshot_date))[1] as first_val,
                       (array_agg(total_value ORDER BY snapshot_date DESC))[1] as last_val
                FROM portfolio_daily_snapshot WHERE portfolio_id = 1 AND snapshot_date >= %s AND snapshot_date < %s
            """, (month_start, calc_date))
            row = cur.fetchone()
        if not row or not row["first_val"]:
            print("  월간 데이터 부족 — 스킵"); return
        first, last = float(row["first_val"]), float(row["last_val"])
        month_return = (last - first) / first * 100 if first > 0 else 0
        max_dd = (float(row["min_val"]) - float(row["max_val"])) / float(row["max_val"]) * 100
        from notifier import send_discord_embed
        embeds = [{"title": f"\U0001f3c6 월간 성과 리포트 — {month_start.strftime('%Y-%m')}",
                   "color": 0x22c55e if month_return >= 0 else 0xef4444,
                   "fields": [{"name": "월간 수익률", "value": f"{month_return:+.2f}%", "inline": True},
                              {"name": "최대 낙폭", "value": f"{max_dd:.1f}%", "inline": True},
                              {"name": "총 자산", "value": f"${last:,.0f}", "inline": True}],
                   "footer": {"text": "QUANT AI v3.7 월간 리포트"}}]
        send_discord_embed(embeds, signal_type="REPORT")
        print(f"  ✅ 월간 리포트 발송 ({month_return:+.2f}%)")
    except Exception as e:
        print(f"  ⚠️ 월간 리포트 실패: {e}")


def start_scheduler():
    try:
        from apscheduler.schedulers.blocking import BlockingScheduler
        from apscheduler.triggers.cron import CronTrigger
    except ImportError:
        print("⚠ APScheduler 미설치! 1회 실행합니다...")
        run_all(); return

    from dotenv import load_dotenv; load_dotenv()
    from db_pool import init_pool; init_pool()

    sched = BlockingScheduler(timezone="US/Eastern")
    sched.add_job(run_all, CronTrigger(day_of_week="mon-fri", hour=21, minute=0, timezone="US/Eastern"),
                  id="daily_batch", name="일일 배치 (21:00 ET)", misfire_grace_time=3600)
    sched.add_job(lambda: run_weekly_report(datetime.now().date()),
                  CronTrigger(day_of_week="sat", hour=9, minute=0, timezone="US/Eastern"),
                  id="weekly_report", name="주간 성과 리포트 (토 09:00)")
    sched.add_job(lambda: run_monthly_report(datetime.now().date()),
                  CronTrigger(day=1, hour=9, minute=0, timezone="US/Eastern"),
                  id="monthly_report", name="월간 성과 리포트 (1일 09:00)")

    print(f"{'='*60}\n  🤖 QUANT AI v3.7 Scheduler 시작\n{'='*60}")
    print(f"  일일 배치:   평일 21:00 ET")
    print(f"  주간 리포트: 토요일 09:00 ET")
    print(f"  월간 리포트: 매월 1일 09:00 ET")
    print(f"  안전장치:    가격실패 {PRICE_FAIL_THRESHOLD_PCT}%↑ 시 중단")
    print(f"{'='*60}")

    try:
        from notifier import send_message
        send_message("🤖 QUANT AI v3.7 Scheduler 시작", channel_key="SYSTEM", private=False)
    except Exception: pass

    try:
        sched.start()
    except (KeyboardInterrupt, SystemExit):
        print("\n[Scheduler] 종료됨")


if __name__ == "__main__":
    from dotenv import load_dotenv; load_dotenv()
    from db_pool import init_pool; init_pool()
    if "--now" in sys.argv:
        print("▶ 즉시 실행 모드")
        run_all()
    else:
        start_scheduler()
