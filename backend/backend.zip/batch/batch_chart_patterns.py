"""
batch/batch_chart_patterns.py — 차트 패턴 감지 (무료, pandas-ta)
================================================================
pandas-ta로 차트 패턴 + 보조 시그널 감지 → chart_patterns 테이블

감지 패턴:
  · Double Bottom / Top (가격 패턴)
  · SMA Cross (Golden/Death Cross — 이미 L3에 있지만 여기서 상세)
  · Bollinger Squeeze Breakout
  · RSI Divergence (가격↓ + RSI↑ = 강세 다이버전스)
  · MACD Histogram Reversal
  · Volume Climax (거래량 극대 + 방향)
  · Support/Resistance 접근

DB: chart_patterns (자동 생성)
스케줄: 매일 L3 이후 실행
API 비용: ❌ 없음 (stock_prices_daily만 사용)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np
from datetime import datetime, date
from db_pool import get_cursor


def _ensure_table():
    """chart_patterns 테이블 자동 생성"""
    with get_cursor() as cur:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS chart_patterns (
                pattern_id    SERIAL PRIMARY KEY,
                stock_id      INTEGER NOT NULL REFERENCES stocks(stock_id),
                calc_date     DATE NOT NULL,
                pattern_type  VARCHAR(50) NOT NULL,
                pattern_name  VARCHAR(100) NOT NULL,
                direction     VARCHAR(10),
                strength      NUMERIC,
                description   TEXT,
                created_at    TIMESTAMPTZ DEFAULT NOW(),
                UNIQUE(stock_id, calc_date, pattern_type)
            )
        """)
    print("[PATTERN] ✅ chart_patterns 테이블 확인")


def _detect_patterns(stock_id: int, close: pd.Series, high: pd.Series,
                     low: pd.Series, volume: pd.Series) -> list:
    """하나의 종목에 대해 모든 패턴 감지"""
    patterns = []
    if len(close) < 50:
        return patterns

    cur_price = float(close.iloc[-1])

    # ── 1. Double Bottom (W 패턴) ──
    try:
        recent = close.tail(60).values
        # 최저점 2개 찾기
        from scipy.signal import argrelextrema
        local_min_idx = argrelextrema(recent, np.less, order=5)[0]
        if len(local_min_idx) >= 2:
            last_two = local_min_idx[-2:]
            p1, p2 = recent[last_two[0]], recent[last_two[1]]
            # 두 저점이 3% 이내이고, 현재가가 그 위에 있으면
            if abs(p1 - p2) / max(p1, p2) < 0.03 and cur_price > max(p1, p2) * 1.02:
                patterns.append({
                    "type": "DOUBLE_BOTTOM",
                    "name": "Double Bottom (W)",
                    "direction": "BULLISH",
                    "strength": round(min(80, (cur_price / max(p1, p2) - 1) * 500), 1),
                    "desc": f"저점 ${p1:.1f}/${p2:.1f}, 현재 ${cur_price:.1f} (+{(cur_price/max(p1,p2)-1)*100:.1f}%)",
                })
    except ImportError:
        pass  # scipy 없으면 스킵
    except Exception:
        pass

    # ── 2. Bollinger Squeeze Breakout ──
    try:
        sma20 = close.rolling(20).mean()
        std20 = close.rolling(20).std()
        bb_width = (2 * std20) / sma20
        
        if len(bb_width.dropna()) >= 20:
            current_width = float(bb_width.iloc[-1])
            avg_width = float(bb_width.tail(120).mean())
            prev_width = float(bb_width.iloc[-2])
            
            # 스퀴즈 후 확장 (이전 폭 < 평균의 60%, 현재 확장 중)
            if prev_width < avg_width * 0.6 and current_width > prev_width * 1.1:
                upper = float(sma20.iloc[-1] + 2 * std20.iloc[-1])
                lower = float(sma20.iloc[-1] - 2 * std20.iloc[-1])
                if cur_price > upper:
                    patterns.append({
                        "type": "BB_BREAKOUT_UP",
                        "name": "Bollinger Squeeze Breakout ↑",
                        "direction": "BULLISH",
                        "strength": 70,
                        "desc": f"스퀴즈 해제 후 상단 돌파 (BB상단=${upper:.1f})",
                    })
                elif cur_price < lower:
                    patterns.append({
                        "type": "BB_BREAKOUT_DOWN",
                        "name": "Bollinger Squeeze Breakout ↓",
                        "direction": "BEARISH",
                        "strength": 70,
                        "desc": f"스퀴즈 해제 후 하단 돌파 (BB하단=${lower:.1f})",
                    })
    except Exception:
        pass

    # ── 3. RSI Divergence ──
    try:
        delta = close.diff()
        gain = delta.clip(lower=0).rolling(14).mean()
        loss = (-delta.clip(upper=0)).rolling(14).mean()
        rs = gain / loss.replace(0, np.nan)
        rsi = 100 - (100 / (1 + rs))
        
        if len(rsi.dropna()) >= 20:
            # 최근 20일: 가격 하락 but RSI 상승 = 강세 다이버전스
            price_20d = float(close.iloc[-1]) - float(close.iloc[-20])
            rsi_20d = float(rsi.iloc[-1]) - float(rsi.iloc[-20])
            
            if price_20d < 0 and rsi_20d > 5:
                patterns.append({
                    "type": "RSI_BULL_DIV",
                    "name": "RSI 강세 다이버전스",
                    "direction": "BULLISH",
                    "strength": round(min(90, rsi_20d * 5), 1),
                    "desc": f"가격 {price_20d/float(close.iloc[-20])*100:.1f}% 하락, RSI +{rsi_20d:.1f} 상승",
                })
            elif price_20d > 0 and rsi_20d < -5:
                patterns.append({
                    "type": "RSI_BEAR_DIV",
                    "name": "RSI 약세 다이버전스",
                    "direction": "BEARISH",
                    "strength": round(min(90, abs(rsi_20d) * 5), 1),
                    "desc": f"가격 +{price_20d/float(close.iloc[-20])*100:.1f}% 상승, RSI {rsi_20d:.1f} 하락",
                })
    except Exception:
        pass

    # ── 4. Volume Climax ──
    try:
        vol_avg = float(volume.tail(20).mean())
        vol_today = float(volume.iloc[-1])
        price_chg = float(close.iloc[-1] - close.iloc[-2])
        
        if vol_today > vol_avg * 3:  # 3배 이상 급증
            direction = "BULLISH" if price_chg > 0 else "BEARISH"
            patterns.append({
                "type": "VOLUME_CLIMAX",
                "name": f"거래량 클라이맥스 ({'상승' if price_chg > 0 else '하락'})",
                "direction": direction,
                "strength": round(min(90, (vol_today / vol_avg) * 15), 1),
                "desc": f"거래량 {vol_today/vol_avg:.1f}배 급증, 가격 {price_chg:+.2f}",
            })
    except Exception:
        pass

    # ── 5. Support/Resistance 접근 ──
    try:
        # 52주 고/저가 기준
        high_52w = float(high.tail(252).max()) if len(high) >= 252 else float(high.max())
        low_52w = float(low.tail(252).min()) if len(low) >= 252 else float(low.min())
        
        dist_high = (high_52w - cur_price) / high_52w * 100
        dist_low = (cur_price - low_52w) / low_52w * 100 if low_52w > 0 else 999
        
        if dist_high < 3:  # 52주 고가 3% 이내
            patterns.append({
                "type": "NEAR_52W_HIGH",
                "name": "52주 신고가 접근",
                "direction": "BULLISH",
                "strength": round(90 - dist_high * 10, 1),
                "desc": f"52주 고가 ${high_52w:.1f}까지 {dist_high:.1f}%",
            })
        if dist_low < 5 and cur_price < float(close.tail(20).mean()):
            patterns.append({
                "type": "NEAR_52W_LOW",
                "name": "52주 신저가 접근",
                "direction": "BEARISH",
                "strength": round(90 - dist_low * 10, 1),
                "desc": f"52주 저가 ${low_52w:.1f}까지 {dist_low:.1f}%",
            })
    except Exception:
        pass

    # ── 6. MA20 지지/저항 ──
    try:
        ma20 = float(close.rolling(20).mean().iloc[-1])
        prev_close = float(close.iloc[-2])
        
        # 가격이 MA20 위로 돌파
        if prev_close < ma20 and cur_price > ma20:
            patterns.append({
                "type": "MA20_CROSS_UP",
                "name": "MA20 상향 돌파",
                "direction": "BULLISH",
                "strength": 60,
                "desc": f"MA20(${ma20:.1f}) 상향 돌파, 현재 ${cur_price:.1f}",
            })
        elif prev_close > ma20 and cur_price < ma20:
            patterns.append({
                "type": "MA20_CROSS_DOWN",
                "name": "MA20 하향 이탈",
                "direction": "BEARISH",
                "strength": 60,
                "desc": f"MA20(${ma20:.1f}) 하향 이탈, 현재 ${cur_price:.1f}",
            })
    except Exception:
        pass

    return patterns


def run_chart_patterns(calc_date: date = None):
    """전 종목 차트 패턴 감지 → chart_patterns 저장"""
    if calc_date is None:
        calc_date = date.today()

    _ensure_table()

    with get_cursor() as cur:
        cur.execute("SELECT stock_id, ticker FROM stocks WHERE is_active = TRUE")
        stocks = [dict(r) for r in cur.fetchall()]

    stock_ids = [s["stock_id"] for s in stocks]

    # 벌크 가격 로드
    print(f"[PATTERN] 가격 데이터 로딩 ({len(stocks)}종목)...")
    from collections import defaultdict
    price_groups = defaultdict(list)

    with get_cursor() as cur:
        cur.execute("""
            SELECT stock_id, trade_date, open_price, high_price, low_price,
                   close_price, volume
            FROM stock_prices_daily
            WHERE stock_id = ANY(%s)
              AND trade_date >= %s - INTERVAL '300 days'
            ORDER BY stock_id, trade_date
        """, (stock_ids, calc_date))
        for r in cur.fetchall():
            price_groups[r["stock_id"]].append(dict(r))

    ok, total_patterns = 0, 0

    for s in stocks:
        stock_id, ticker = s["stock_id"], s["ticker"]
        rows = price_groups.get(stock_id, [])
        if len(rows) < 50:
            continue

        df = pd.DataFrame(rows)
        close = df["close_price"].astype(float)
        high = df["high_price"].astype(float)
        low = df["low_price"].astype(float)
        volume = df["volume"].astype(float)

        patterns = _detect_patterns(stock_id, close, high, low, volume)

        for p in patterns:
            with get_cursor() as cur:
                cur.execute("""
                    INSERT INTO chart_patterns (
                        stock_id, calc_date, pattern_type, pattern_name,
                        direction, strength, description
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (stock_id, calc_date, pattern_type) DO UPDATE SET
                        pattern_name = EXCLUDED.pattern_name,
                        direction    = EXCLUDED.direction,
                        strength     = EXCLUDED.strength,
                        description  = EXCLUDED.description
                """, (stock_id, calc_date, p["type"], p["name"],
                      p["direction"], p["strength"], p["desc"]))
            total_patterns += 1

        ok += 1
        if ok % 100 == 0:
            print(f"[PATTERN]   {ok}/{len(stocks)} 완료...")

    print(f"[PATTERN] ✅ {ok}종목 분석, {total_patterns}개 패턴 감지")


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    from db_pool import init_pool
    init_pool()
    run_chart_patterns()